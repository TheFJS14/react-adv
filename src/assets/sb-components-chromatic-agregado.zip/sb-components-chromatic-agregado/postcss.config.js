module.exports = {
    // Add your installed PostCSS plugins here:
    plugins: [
      // require('autoprefixer'),
      // require('postcss-color-rebeccapurple'),
    ],
};